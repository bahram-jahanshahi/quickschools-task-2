package com.quickschools.reportdesigner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportDesignerApplicationTests {

    @Test
    void contextLoads() {
    }

}
