package com.quickschools.reportdesigner.entities.enums;

public enum FieldTypeEnum {
    Integer, String, Boolean, Date;
}
