package com.quickschools.reportdesigner.entities.enums;

public enum CardinalityEnum {
    OneToOne, OneToMany, ManyToOne, ManyToMany;
}
