package com.quickschools.reportdesigner.modules.reportdesigner.features.sqlgenerator.service.exceptions;

public class SqlGenerationException extends Exception {
    public SqlGenerationException(String message) {
        super(message);
    }
}
